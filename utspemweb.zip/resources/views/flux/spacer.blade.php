<div {{ $attributes->class('flex-1') }} data-flux-spacer></div>
